import Foundation

enum Ingredient: String, CaseIterable {
    case spinach = "Spinach"
    case broccoli = "Broccoli"
    case carrot = "Carrot"
    case pasta = "Pasta"
    case tomatoSauce = "Tomato sauce"
    case meat = "Meat"
    case chicken = "Chicken"
    case rice = "Rice"
    case yogurth = "Yogurth"
    case fries = "Fries"
    case cola = "Cola"
    case iceTea = "Ice tea"
    case Ayran = "Ayran"
    case BubbleTea = "Bubble Tea"
    case orangeJuice = "Orange Juice"
    case cake = "Cake"
    case puding = "Puding"
    case damlaGum = "Damla Gum"
    case sugar = "Sugar (%0.1)"
    case sugar2x = "Sugar"
    case milk = "Milk"
    case fistik = "Fistik"
    case pirinc = "Pirinc"
}

