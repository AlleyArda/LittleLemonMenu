import SwiftUI

struct MenuItemDetailsView: View {
    let menuItem: MenuItem
    let imagelemon = "lemonpng2"
    var body: some View {
        VStack {
            Image(imagelemon)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 200)
                .padding()

            Text("Price: \(menuItem.price, specifier: "%.2f")$")
                .font(.title2)
                .padding()

            Text("Ordered: \(menuItem.ordersCount)")
                .font(.title3)
                .padding()

            Text("Ingredients:")
                .font(.headline)
                .padding(.top)

            ForEach(menuItem.ingredients, id: \.self) { ingredient in
                Text(ingredient.rawValue.capitalized)
            }

            Spacer()
        }
        .padding()
        .navigationTitle(menuItem.title)
    }
}

struct MenuItemDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleMenuItem = MenuItem(
            title: "Fries", image: "Fried Potatoes Photo",
            ingredients: [.fries],
            price: 19.99,
            category: .food,
            ordersCount: 7
        )

        MenuItemDetailsView(menuItem: sampleMenuItem)
    }
}

