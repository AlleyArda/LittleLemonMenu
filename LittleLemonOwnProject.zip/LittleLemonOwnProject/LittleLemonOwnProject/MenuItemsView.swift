import SwiftUI

import SwiftUI

struct MenuItemsView: View {
    @ObservedObject var viewModel = MenuViewViewModel()
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    if viewModel.selectedCategory == .all || viewModel.selectedCategory == .food {
                        Text("Food")
                            .font(.headline)
                            .padding([.leading, .top])
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) {
                            ForEach(viewModel.menuItems.filter { $0.category == .food }) { item in
                                MenuItemCardView(menuItem: item)
                            }
                        }
                    }
                    
                    if viewModel.selectedCategory == .all || viewModel.selectedCategory == .drink {
                        Text("Drinks")
                            .font(.headline)
                            .padding([.leading, .top])
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) {
                            ForEach(viewModel.menuItems.filter { $0.category == .drink }) { item in
                                MenuItemCardView(menuItem: item)
                            }
                        }
                    }
                    
                    if viewModel.selectedCategory == .all || viewModel.selectedCategory == .dessert {
                        Text("Dessert")
                            .font(.headline)
                            .padding([.leading, .top])
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) {
                            ForEach(viewModel.menuItems.filter { $0.category == .dessert }) { item in
                                MenuItemCardView(menuItem: item)
                            }
                        }
                    }
                }
            }
            .navigationBarTitle("Menu")
            .navigationBarItems(trailing: Button(action: {
                viewModel.showFilterOptions.toggle()
            }) {
                Image(systemName: "slider.horizontal.3")
            })
            .sheet(isPresented: $viewModel.showFilterOptions) {
                MenuItemsOptionView(viewModel: viewModel)
            }
        }
    }
}



struct MenuItemsView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemsView()
    }
}

