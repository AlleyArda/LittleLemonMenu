//
//  LittleLemonOwnProjectApp.swift
//  LittleLemonOwnProject
//
//  Created by Arda Kulaksız on 22.06.2024.
//

import SwiftUI

@main
struct LittleLemonOwnProjectApp: App {
    var body: some Scene {
        WindowGroup {
            MenuItemsView()
        }
    }
}
