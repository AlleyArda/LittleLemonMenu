import SwiftUI

struct MenuItemCardView: View {
    let menuItem: MenuItem
    var body: some View {
        NavigationLink(destination: MenuItemDetailsView(menuItem: menuItem)) {
            VStack {
                Image(menuItem.image) // Assuming `imageName` is a property in MenuItem
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .clipped() // Ensures the image stays within the frame
                                
                
                Text(menuItem.title)
                    .font(.caption)
                    .padding(.top, 5)
                Text(String(menuItem.price))
                    .font(.caption2)
                    .padding(.top, 2)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
        }
    }
}




