import Foundation


class MenuViewViewModel: ObservableObject {
    @Published var menuItems: [MenuItem] = mockMenuItems
    @Published var selectedCategory: MenuCategory = .all
    @Published var sortOption: SortOption = .mostPopular
    @Published var showFilterOptions: Bool = false
    
    public var images = [
        "saladspinac",
        
       
    ]
    
    
    
    var sortedAndFilteredItems: [MenuItem] {
        var filteredItems: [MenuItem]
        
        switch selectedCategory {
        case .all:
            filteredItems = menuItems
        case .food:
            filteredItems = menuItems.filter { $0.category == .food }
        case .drink:
            filteredItems = menuItems.filter { $0.category == .drink }
        case .dessert:
            filteredItems = menuItems.filter { $0.category == .dessert }
        }
        
        enum SortOption: String, CaseIterable {
            case mostPopular = "Most Popular"
            case price = "Price $-$$$"
            case aToZ = "A-Z"
        }
        return filteredItems
    }
    
    func updateCategory(_ category: MenuCategory) {
        selectedCategory = category
    }
    
    func updateSortOption(_ option: SortOption) {
        sortOption = option
    }
}


// Food items
let mockFoodItems: [MenuItem] = [
    MenuItem(title: "Spinach & Broccoli Salad", image: "saladspinac" , ingredients: [.spinach, .broccoli], price: 12.99, category: .food, ordersCount: 10),
    MenuItem(title: "Carrot & Pasta Delight", image: "Pasta with Nuts Restaurant", ingredients: [.carrot, .pasta], price: 15.99, category: .food, ordersCount: 20),
    MenuItem(title: "Tomato Spinach Pasta", image: "Pasta Salad Bowl", ingredients: [.tomatoSauce, .spinach], price: 10.99, category: .food, ordersCount: 15),
    MenuItem(title: "Broccoli Carrot Stir Fry", image: "Carrot Cutting Kitchen", ingredients: [.broccoli, .carrot], price: 9.99, category: .food, ordersCount: 8),
    MenuItem(title: "Pasta with Tomato Sauce", image: "Unrecognizable Woman with Fork", ingredients: [.pasta, .tomatoSauce], price: 11.99, category: .food, ordersCount: 18),
    MenuItem(title: "Spinach Pasta Supreme", image: "Pasta Salad Bowl", ingredients: [.spinach, .pasta], price: 13.99, category: .food, ordersCount: 12),
    MenuItem(title: "Broccoli with Tomato Sauce", image: "Spoon over Soup with Broccoli", ingredients: [.broccoli, .tomatoSauce], price: 14.99, category: .food, ordersCount: 22),
    MenuItem(title: "Carrot Spinach Medley", image: "Carrot Cutting Kitchen", ingredients: [.carrot, .spinach], price: 16.99, category: .food, ordersCount: 30),
    MenuItem(title: "Rice and Chicken", image: "Dinner Dish with Rice", ingredients: [.rice, .chicken], price: 17.99, category: .food, ordersCount: 25),
    MenuItem(title: "Rice and Meat", image: "meatandrice", ingredients: [.rice, .meat], price: 18.99, category: .food, ordersCount: 5),
    MenuItem(title: "Fries", image: "Fried Potatoes Photo", ingredients: [.fries], price: 19.99, category: .food, ordersCount: 7),
    MenuItem(title: "Yogurth and Pasta", image: "yogurthpasta", ingredients: [.pasta, .yogurth], price: 20.99, category: .food, ordersCount: 11)
]

// Drink items
let mockDrinkItems: [MenuItem] = [
    MenuItem(title: "Tomato Sauce Smoothie", image: "Unrecognizable woman with red juice", ingredients: [.tomatoSauce], price: 5.99, category: .drink, ordersCount: 30),
    MenuItem(title: "Spinach Shake", image: "Broccoli Shake Glass", ingredients: [.spinach], price: 4.99, category: .drink, ordersCount: 40),
    MenuItem(title: "Orange Juice", image: "Clear Glass Jar on Block", ingredients: [.orangeJuice], price: 6.99, category: .drink, ordersCount: 35),
    MenuItem(title: "Carrot Drink", image: "Carrot Juice Wine Glass", ingredients: [.carrot], price: 7.99, category: .drink, ordersCount: 20),
    MenuItem(title: "Cola", image: "Clear Drinking Glass Photo", ingredients: [.cola], price: 3.99, category: .drink, ordersCount: 25),
    MenuItem(title: "Ice Tea", image: "Clear Highball Glass with Iced Tea", ingredients: [.iceTea], price: 8.99, category: .drink, ordersCount: 15),
    MenuItem(title: "Ayran", image: "Ayrandrink", ingredients: [.Ayran], price: 9.99, category: .drink, ordersCount: 10),
    MenuItem(title: "Bubble Tea", image: "Bubble Tea Person", ingredients: [.BubbleTea], price: 10.99, category: .drink, ordersCount: 5)
]

// Dessert items
let mockDessertItems: [MenuItem] = [
    MenuItem(title: "Damla Pudding", image: "damla", ingredients: [.damlaGum , .puding , .sugar], price: 1323.24, category: .dessert, ordersCount: 2),
    MenuItem(title: "Pudding", image: "Dessert Jars by Ella Olsson", ingredients: [.puding, .sugar2x], price: 7.99, category: .dessert, ordersCount: 15),
    MenuItem(title: "sutlac", image: "sutlac", ingredients: [.sugar2x , .milk , .pirinc], price: 8.99, category: .dessert, ordersCount: 20),
    MenuItem(title: "baklava", image: "Bread Close Up", ingredients: [.sugar2x, .fistik], price: 9.99, category: .dessert, ordersCount: 25)
]

// Tüm menü öğelerini birleştirme
let mockMenuItems: [MenuItem] = mockFoodItems + mockDrinkItems + mockDessertItems
