import Foundation
import SwiftUI

protocol MenuItemProtocol {
    var id: UUID { get }
    var price: Double { get }
    var title: String { get }
    var image: String {get}
    var category: MenuCategory { get }
    var ordersCount: Int { get set }
    var ingredients: [Ingredient] { get set }
}

struct MenuItem: Identifiable, MenuItemProtocol {
    let id = UUID()
    let title: String
    let image: String
    var ingredients: [Ingredient]
    let price: Double
    let category: MenuCategory
    var ordersCount: Int = 0
}

enum MenuCategory: String, CaseIterable {
    case all = "All"
    case food = "Food"
    case drink = "Drink"
    case dessert = "Dessert"
}

enum SortOption: String, CaseIterable {
    case mostPopular = "Most Popular"
    case price = "Price $-$$$"
    case alphabetically = "A-Z"
}

