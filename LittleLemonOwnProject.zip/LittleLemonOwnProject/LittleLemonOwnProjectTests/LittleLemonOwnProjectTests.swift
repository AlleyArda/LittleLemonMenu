//
//  LittleLemonOwnProjectTests.swift
//  LittleLemonOwnProjectTests
//
//  Created by Arda Kulaksız on 22.06.2024.
//

import XCTest
@testable import LittleLemonOwnProject

final class LittleLemonOwnProjectTests: XCTestCase {

    func testMenuItemTitle() {
        let menuItem = MenuItem(title: "Test Dish", image: "testimage", ingredients: [], price: 10.0, category: .food)
           XCTAssertEqual(menuItem.title, "Test Dish")
       }
       
       func testMenuItemIngredients() {
           let ingredients: [Ingredient] = [.spinach, .tomatoSauce]
           let menuItem = MenuItem(title: "Test Dish", image: "testimage", ingredients: ingredients, price: 10.0, category: .food)
           XCTAssertEqual(menuItem.ingredients, ingredients)
       }

}
